from redis_conn import redis_client
from mysql_conn import cursor
from logger_config import setup_logger

logger = setup_logger()

def get_staff_row_count():
    count = redis_client.get('staff_row_count')
    if not count:
        cursor.execute("SELECT COUNT(*) FROM staff")
        count = cursor.fetchone()['COUNT(*)']
        redis_client.set('staff_row_count', count)
        redis_client.expire('staff_row_count', 3600)
    return count

def get_film_category_counts():
    data = redis_client.get('film_category_counts')
    if not data:
        cursor.execute("""
            SELECT c.name AS category_name, COUNT(f.film_id) AS film_count
            FROM category c
            LEFT JOIN film_category fc ON c.category_id = fc.category_id
            LEFT JOIN film f ON fc.film_id = f.film_id
            GROUP BY c.name
            ORDER BY film_count DESC
        """)
        result = cursor.fetchall()
        redis_client.set('film_category_counts', str(result))
        redis_client.expire('film_category_counts', 3600)
        return result
    return eval(data)  