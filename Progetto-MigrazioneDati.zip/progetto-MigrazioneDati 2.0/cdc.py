from mysql_conn import cursor, get_column_names
from mongo_conn import mongo_db2
from redis_conn import redis_client
from logger_config import setup_logger
from conversion import convert_for_mongo
from pymysqlreplication import BinLogStreamReader
from pymysqlreplication.row_event import WriteRowsEvent, UpdateRowsEvent, DeleteRowsEvent
from config import mysql_settings, mysql_db_name
from minio_utils import upload_to_minio, delete_from_minio
from relational_to_document import (build_nested_staff_document, build_nested_film_document, 
                                    build_nested_customer_document, build_nested_customer_document_from_db)

logger = setup_logger()

def process_blob_fields(table, data):
    """Cerca e carica campi BLOB su MinIO, sostituendo i dati binari con URL."""
    for key, value in data.items():
        if isinstance(value, (bytes, bytearray)):
            file_url = upload_to_minio(value)
            if file_url:
                data[key] = file_url
    return data

def update_nested_data(collection_name, pk_field, data):
    """Funzione per aggiornare i documenti nelle collezioni nidificate di MongoDB."""
    collection = mongo_db2[collection_name]

    # Rimuove _id se presente
    data.pop('_id', None)

    # Usa upsert per assicurarti che il documento venga creato se non esiste
    result = collection.update_one({pk_field: data[pk_field]}, {"$set": data}, upsert=True)

    if result.matched_count > 0:
        logger.info(f"Updated nested data in {collection_name}: {data}")
    else:
        logger.info(f"Inserted new nested data in {collection_name}: {data}")

def start_cdc():
    logger.info("=" * 50)
    logger.info("Avvio Change Data Capture da binlog...")
    logger.info("=" * 50)

    log_file = redis_client.get('cdc_binlog_file')
    log_pos = redis_client.get('cdc_binlog_pos')

    if log_file and log_pos:
        log_file = log_file.decode() if isinstance(log_file, bytes) else log_file
        log_pos = int(log_pos)
        logger.info(f"Riprendendo da {log_file}:{log_pos}")
    else:
        logger.info("Inizio CDC dalla posizione corrente di MySQL.")
        log_file = None
        log_pos = None

    stream = BinLogStreamReader(
        connection_settings=mysql_settings,
        server_id=101,
        only_events=[WriteRowsEvent, UpdateRowsEvent, DeleteRowsEvent],
        only_schemas=[mysql_db_name],
        blocking=True,  # Per monitorare in tempo reale
        resume_stream=True,
        log_file=log_file,
        log_pos=log_pos
    )

    for binlogevent in stream:
        table = binlogevent.table
        column_names = get_column_names(table)

        logger.info(f"Processing binlog event for table: {table}")

        for row in binlogevent.rows:
            try:
                # Scrittura dei nuovi dati
                if isinstance(binlogevent, WriteRowsEvent):
                    data = {
                        column_names[i]: convert_for_mongo(value)
                        for i, (column, value) in enumerate(row["values"].items())
                    }
                    data = process_blob_fields(table, data)

                    # Aggiorna le collezioni nidificate
                    if table == 'staff':
                        full_staff_doc = build_nested_staff_document(data)
                        update_nested_data('staff_nested', 'staff_id', full_staff_doc)

                    elif table == 'payment':
                        update_nested_data('customers_nested', 'customer_id', data)
                        staff_id = data.get('staff_id')
                        if staff_id:
                            nested_payment = {
                                "payment_id": data["payment_id"],
                                "amount": float(data["amount"]),
                                "payment_date": data["payment_date"].isoformat()
                            }
                            mongo_db2['staff_nested'].update_one(
                                {"staff_id": staff_id},
                                {"$addToSet": {"payments": nested_payment}}
                            )
                            logger.info(f"Aggiunto pagamento a staff_nested per staff_id {staff_id}: {nested_payment}")

                    if table == 'film':
                        full_film_doc = build_nested_film_document(data)
                        update_nested_data('film_nested', 'film_id', full_film_doc)


                    elif table == 'actor':
                        actor_id = data.get('actor_id')
                        first_name = data.get('first_name')
                        last_name = data.get('last_name')

                        if actor_id and first_name and last_name:
                            nested_actor = {
                                "actor_id": actor_id,
                                "name": f"{first_name} {last_name}"
                            }

                            try:
                                # Inserisci o aggiorna l'attore nella collezione Mongo (esempio: 'actor_nested')
                                result = mongo_db2['actor_nested'].update_one(
                                    {"actor_id": actor_id},
                                    {"$set": nested_actor},
                                    upsert=True
                                )

                                if result.modified_count > 0:
                                    logger.info(f"Aggiornato attore actor_id={actor_id} in actor_nested.")
                                else:
                                    logger.info(f"Aggiunto nuovo attore actor_id={actor_id} in actor_nested.")
                            except Exception as e:
                                logger.error(f"Errore aggiornando actor_nested per actor_id={actor_id}: {e}")
                        else:
                            logger.warning(f"Dati incompleti per actor_id={actor_id}: first_name o last_name mancanti.")

                    elif table == 'film_actor':
                        film_id = data.get("film_id")
                        actor_id = data.get("actor_id")

                        if film_id is not None and actor_id is not None:
                            try:
                                # Controlla se il documento film esiste
                                film_doc = mongo_db2['film_nested'].find_one({"film_id": film_id})
                                if not film_doc:
                                    logger.warning(f"Documento film_nested non trovato per film_id {film_id}. Attesa o skip.")
                                    continue  # Passa al prossimo record

                                # Recupera dati attore
                                cursor.execute("SELECT first_name, last_name FROM actor WHERE actor_id = %s", (actor_id,))
                                actor_data = cursor.fetchone()

                                if actor_data:
                                    first_name = actor_data["first_name"]
                                    last_name = actor_data["last_name"]

                                    if first_name and last_name:  # Verifica se i dati dell'attore sono completi
                                        actor_name = f"{first_name} {last_name}"
                                        nested_actor = {
                                            "actor_id": actor_id,
                                            "name": actor_name
                                        }

                                        # Aggiungi attore al documento del film
                                        result = mongo_db2['film_nested'].update_one(
                                            {"film_id": film_id},
                                            {"$addToSet": {"actors": nested_actor}},
                                            upsert=True  # Usa upsert per evitare duplicati
                                        )
                                        logger.info(f"Aggiunto nuovo attore a film_nested per film_id {film_id}: {nested_actor}")
                                    else:
                                        logger.warning(f"Nome attore incompleto per actor_id {actor_id}. Saltato.")
                                else:
                                    # Facoltativo: inserisci in una coda per retry
                                    logger.warning(f"Attore non trovato per actor_id {actor_id}. Potrebbe non essere stato ancora inserito.")
                                    # Potresti qui inserire nella coda per retry
                            except Exception as e:
                                logger.error(f"Errore durante l'elaborazione di film_actor per film_id={film_id} e actor_id={actor_id}: {e}")
                        else:
                            logger.error(f"film_id o actor_id mancanti nei dati: {data}")

                    
                    elif table == 'film_category':
                        film_id = data.get("film_id")
                        category_id = data.get("category_id")

                        if film_id is not None and category_id is not None:
                            try:
                                # Controlla se il documento film esiste
                                film_doc = mongo_db2['film_nested'].find_one({"film_id": film_id})
                                if not film_doc:
                                    logger.warning(f"Documento film_nested non trovato per film_id {film_id}. Attesa o skip.")
                                    return

                                # Recupera i dati della categoria
                                cursor.execute("SELECT name FROM category WHERE category_id = %s", (category_id,))
                                category_data = cursor.fetchone()

                                if category_data:
                                    category_name = category_data["name"]

                                    # Crea il documento per la categoria
                                    nested_category = {
                                        "category_id": category_id,
                                        #"name": category_name
                                    }

                                    # Aggiunge la categoria al documento del film
                                    result = mongo_db2['film_nested'].update_one(
                                        {"film_id": film_id},
                                        {"$addToSet": {"categories": nested_category}}  # Evita duplicati
                                    )

                                    if result.modified_count > 0:
                                        logger.info(f"Aggiunta nuova categoria a film_nested per film_id {film_id}: {nested_category}")
                                    else:
                                        logger.info(f"Categoria già presente per film_id {film_id}: {nested_category}")

                                else:
                                    logger.warning(f"Categoria non trovata per category_id {category_id}. Potrebbe non essere stata ancora inserita.")
                                    # Facoltativo: inserisci in una coda per retry
                            except Exception as e:
                                logger.error(f"Errore durante l'elaborazione di film_category: {e}")
                        else:
                            logger.error(f"film_id o category_id mancanti nei dati: {data}")



                    if table == 'customer':
                        full_customer_doc = build_nested_customer_document(data)
                        update_nested_data('customers_nested', 'customer_id', full_customer_doc)
                    elif table == 'rental':
                        # Recupera il film_title dalla tabella 'film' basato su inventory_id
                        inventory_id = data.get('inventory_id')
                        if inventory_id:
                            cursor.execute("""
                                SELECT f.title
                                FROM film f
                                JOIN inventory i ON f.film_id = i.film_id
                                WHERE i.inventory_id = %s
                            """, (inventory_id,))
                            film = cursor.fetchone()
                            if film:
                                data['film_title'] = film['title']
                            else:
                                logger.warning(f"Film non trovato per inventory_id: {inventory_id}")

                        # Aggiungi il noleggio al cliente (customer_nested)
                        customer_id = data.get('customer_id')
                        if customer_id is not None:
                            nested_rental = {
                                "rental_id": data["rental_id"],
                                "film_title": data["film_title"],
                                "rental_date": data["rental_date"].isoformat() if isinstance(data["rental_date"], (str,)) else data["rental_date"],
                                "return_date": data["return_date"].isoformat() if isinstance(data["return_date"], (str,)) else data["return_date"]
                            }

                            result = mongo_db2['customers_nested'].update_one(
                                {"customer_id": customer_id},
                                {"$addToSet": {"rentals": nested_rental}}
                            )

                            logger.info(f"Aggiunto nuovo noleggio a customer_nested per customer_id {customer_id}: {nested_rental}")

                    
                # Gestione dell'aggiornamento dei dati
                elif isinstance(binlogevent, UpdateRowsEvent):
                    old = {
                        column_names[i]: convert_for_mongo(value)
                        for i, (column, value) in enumerate(row["before_values"].items())
                    }
                    new = {
                        column_names[i]: convert_for_mongo(value)
                        for i, (column, value) in enumerate(row["after_values"].items())
                    }

                    # Rimuove _id prima dell'aggiornamento
                    new.pop('_id', None)

                    new = process_blob_fields(table, new)

                    # Rimuove i file BLOB precedenti se sono stati aggiornati
                    for k in old:
                        if isinstance(old[k], str) and old[k].startswith("http://") and old[k] != new.get(k):
                            delete_from_minio(old[k])

                    pk_field = next(iter(old))  # Trova il campo di chiave primaria
                    mongo_db2[table].update_one({pk_field: old[pk_field]}, {"$set": new})
                    logger.info(f"Update in {table}: {new}")

                    # Aggiorna le collezioni nidificate
                 
                    if table == 'staff':
                        update_nested_data('staff_nested', pk_field, new)

                    elif table == 'payment':
                        update_nested_data('customers_nested', 'customer_id', new)
                        staff_id = new.get('staff_id')
                        if staff_id:
                            updated_payment = {
                                "payment_id": new["payment_id"],
                                "amount": float(new["amount"]),
                                "payment_date": new["payment_date"].isoformat()
                            }
                            mongo_db2['staff_nested'].update_one(
                                {"staff_id": staff_id},
                                {"$pull": {"payments": {"payment_id": new["payment_id"]}}}
                            )
                            mongo_db2['staff_nested'].update_one(
                                {"staff_id": staff_id},
                                {"$addToSet": {"payments": updated_payment}}
                            )
                            logger.info(f"Aggiornato pagamento in staff_nested per staff_id {staff_id}: {updated_payment}")

                    elif table == 'address':
                        update_address_references(new["address_id"], new)

                
                    if table == "film":
                        film_id = new.get("film_id")

                        if film_id is not None:
                            try:
                                # Rimuove i campi di tipo 'set' prima di inviarli a MongoDB
                                fields_to_remove = [key for key, value in new.items() if isinstance(value, set)]
                                for key in fields_to_remove:
                                    new.pop(key, None)  # Rimuove il campo dal dizionario

                                logger.debug(f"Removed 'set' fields: {fields_to_remove}")

                                updated_fields = {}

                                for field in [
                                    "title", "description", "release_year", "original_language_id",
                                    "rental_duration", "rental_rate", "length", "replacement_cost",
                                    "rating", "special_features", "last_update"
                                ]:
                                    if field in new:
                                        updated_fields[field] = new[field]

                                # Aggiungi campo "language" se disponibile
                                if "language_id" in new:
                                    cursor.execute("SELECT name FROM language WHERE language_id = %s", (new["language_id"],))
                                    language_data = cursor.fetchone()
                                    if language_data:
                                        updated_fields["language"] = {
                                            "language_id": new["language_id"],
                                            "name": language_data["name"]
                                        }

                                if updated_fields:
                                    result = mongo_db2['film_nested'].update_one(
                                        {"film_id": film_id},
                                        {"$set": updated_fields}
                                    )
                                    if result.modified_count > 0:
                                        logger.info(f"Aggiornato film_id={film_id} in film_nested: {updated_fields}")
                                    else:
                                        logger.info(f"Nessun cambiamento per film_id={film_id} in film_nested")
                                else:
                                    logger.info(f"Nessun campo aggiornabile per film_id={film_id}")

                            except Exception as e:
                                logger.error(f"Errore durante l'aggiornamento di film_nested: {e}")
                        else:
                            logger.error(f"film_id mancante nei dati UPDATE: {new}")


                    elif table == "film_text":
                        film_id = new.get("film_id")

                        if film_id is not None:
                            try:
                                # I campi che vuoi sincronizzare da film_text a film_nested
                                updated_fields = {}

                                for field in ["title", "description"]:
                                    if field in new:
                                        updated_fields[field] = new[field]

                                if updated_fields:
                                    # Aggiornamento di film_nested con i nuovi campi provenienti da film_text
                                    result = mongo_db2['film_nested'].update_one(
                                        {"film_id": film_id},
                                        {"$set": updated_fields}
                                    )
                                    if result.modified_count > 0:
                                        logger.info(f"Aggiornato film_id={film_id} in film_nested da film_text: {updated_fields}")
                                    else:
                                        logger.info(f"Nessun cambiamento per film_id={film_id} in film_nested (da film_text)")
                                else:
                                    logger.info(f"Nessun campo aggiornabile per film_id={film_id} da film_text")

                            except Exception as e:
                                logger.error(f"Errore durante l'aggiornamento di film_nested da film_text: {e}")
                        else:
                            logger.error(f"film_id mancante nei dati UPDATE in film_text: {new}")


                    elif table == 'film_actor':
                        film_id = data.get("film_id")
                        actor_id = data.get("actor_id")

                        if film_id is not None and actor_id is not None:
                            try:
                                film_doc = mongo_db2['film_nested'].find_one({"film_id": film_id})
                                if not film_doc:
                                    logger.warning(f"Documento film_nested non trovato per film_id {film_id}. Attesa o skip.")
                                    return

                                # Recupera dati attore
                                cursor.execute("SELECT first_name, last_name FROM actor WHERE actor_id = %s", (actor_id,))
                                actor_data = cursor.fetchone()

                                if actor_data:
                                    first_name = actor_data["first_name"]
                                    last_name = actor_data["last_name"]
                                    actor_name = f"{first_name} {last_name}"

                                    nested_actor = {
                                        "actor_id": actor_id,
                                        "name": actor_name
                                    }

                                    # Tenta aggiornamento
                                    result = mongo_db2['film_nested'].update_one(
                                        {"film_id": film_id, "actors.actor_id": actor_id},
                                        {"$set": {"actors.$": nested_actor}}
                                    )

                                    if result.matched_count > 0:
                                        logger.info(f"Aggiornato attore in film_nested per film_id {film_id}: {nested_actor}")
                                    else:
                                        # Se non trovato, aggiungi
                                        add_result = mongo_db2['film_nested'].update_one(
                                            {"film_id": film_id},
                                            {"$addToSet": {"actors": nested_actor}}
                                        )
                                        if add_result.modified_count > 0:
                                            logger.info(f"Aggiunto attore in film_nested per film_id {film_id}: {nested_actor}")
                                        else:
                                            logger.warning(f"Attore non aggiunto (forse già presente?) per film_id {film_id}: {nested_actor}")
                                else:
                                    logger.warning(f"Attore non trovato per actor_id {actor_id}. Potrebbe non essere stato ancora inserito.")

                            except Exception as e:
                                logger.error(f"Errore durante l'elaborazione di film_actor: {e}")
                        else:
                            logger.error(f"film_id o actor_id mancanti nei dati: {data}")
     
                    elif table == 'actor':
                        actor_id = new.get("actor_id")

                        if actor_id is not None:
                            try:
                                # Rimuove i campi di tipo 'set' prima di inviarli a MongoDB
                                fields_to_remove = [key for key, value in new.items() if isinstance(value, set)]
                                for key in fields_to_remove:
                                    new.pop(key, None)  # Rimuove il campo dal dizionario

                                logger.debug(f"Removed 'set' fields: {fields_to_remove}")

                                updated_fields = {}

                                # Unisci first_name e last_name in name
                                if "first_name" in new and "last_name" in new:
                                    updated_fields["name"] = f"{new['first_name']} {new['last_name']}"
                                else:
                                    logger.warning(f"Missing first_name or last_name for actor_id={actor_id}")

                                # Se ci sono aggiornamenti da fare, aggiorna i documenti in film_nested
                                if updated_fields:
                                    result = mongo_db2['film_nested'].update_many(
                                        {"actors.actor_id": actor_id},  # Cerca film con l'attore specifico
                                        {"$set": {"actors.$.name": updated_fields["name"]}}
                                    )

                                    if result.modified_count > 0:
                                        logger.info(f"Aggiornato attore_id={actor_id} in film_nested con name={updated_fields['name']}")
                                    else:
                                        logger.info(f"Nessun cambiamento per attore_id={actor_id} in film_nested")
                                else:
                                    logger.info(f"Nessun campo aggiornabile per attore_id={actor_id}")

                            except Exception as e:
                                logger.error(f"Errore durante l'aggiornamento di film_nested: {e}")
                        else:
                            logger.error(f"actor_id mancante nei dati UPDATE: {new}")


                    elif table == 'film_category':
                        film_id = new.get('film_id')
                        category_id = new.get('category_id')

                        if film_id is not None and category_id is not None:
                            try:
                                # Ottieni il nome della categoria da tabella category
                                cursor.execute("SELECT name FROM category WHERE category_id = %s", (category_id,))
                                category_data = cursor.fetchone()

                                if not category_data:
                                    logger.warning(f"Categoria non trovata per category_id={category_id}")
                                    return

                                category_name = category_data["name"]

                                updated_category = {
                                    "category_id": category_id,
                                    "name": category_name
                                }

                                # Imposta l'intero array categories con un solo elemento
                                mongo_db2['film_nested'].update_one(
                                    {"film_id": film_id},
                                    {"$set": {"categories": [updated_category]}}
                                )

                                logger.info(f"Campo categories sostituito con uno nuovo in film_nested per film_id={film_id}: {updated_category}")

                            except Exception as e:
                                logger.error(f"Errore durante aggiornamento film_category: {e}")
                        else:
                            logger.error(f"Dati mancanti per film_category: {new}")


                    if table == 'customer':
                        update_nested_data('customers_nested', pk_field, new)

                    elif table == 'rental':
                        customer_id = new.get('customer_id')
                        inventory_id = new.get('inventory_id')

                        if customer_id and inventory_id:
                            cursor.execute("""
                                SELECT f.title
                                FROM film f
                                JOIN inventory i ON f.film_id = i.film_id
                                WHERE i.inventory_id = %s
                            """, (inventory_id,))
                            film = cursor.fetchone()
                            film_title = film["title"] if film else "Titolo sconosciuto"

                            updated_rental = {
                                "rental_id": new["rental_id"],
                                "rental_date": new["rental_date"].isoformat(),
                                "return_date": new["return_date"].isoformat(),
                                "film_title": film_title
                            }

                            # Rimuove il vecchio rental
                            mongo_db2['customers_nested'].update_one(
                                {"customer_id": customer_id},
                                {"$pull": {"rentals": {"rental_id": new["rental_id"]}}}
                            )

                            # Aggiunge il nuovo rental aggiornato
                            mongo_db2['customers_nested'].update_one(
                                {"customer_id": customer_id},
                                {"$addToSet": {"rentals": updated_rental}}
                            )

                            logger.info(f"Aggiornato rental in customers_nested (update): {updated_rental}")

                    if table == 'address':
                        updated_address_id = new['address_id']
                        # Recupera tutti i customer con quell'indirizzo
                        affected_customers = mongo_db2['customers_nested'].find({"address.address_id": updated_address_id})

                        for customer in affected_customers:
                            customer_id = customer["customer_id"]

                            # Ricarica tutti i dati aggiornati (come nel metodo migrate/build_nested)
                            full_customer_doc = build_nested_customer_document_from_db(customer_id)
                            update_nested_data('customers_nested', 'customer_id', full_customer_doc)


                    if table == 'city':
                        city_id = new['city_id']
                        cursor.execute("SELECT address_id FROM address WHERE city_id = %s", (city_id,))
                        address_ids = [row["address_id"] for row in cursor.fetchall()]
                        
                        affected_customers = mongo_db2['customers_nested'].find({"address.address_id": {"$in": address_ids}})
                        
                        for customer in affected_customers:
                            customer_id = customer["customer_id"]
                            full_customer_doc = build_nested_customer_document_from_db(customer_id)
                            update_nested_data('customers_nested', 'customer_id', full_customer_doc)
  

                # Gestione della cancellazione dei dati
                elif isinstance(binlogevent, DeleteRowsEvent):
                    data = {
                        column_names[i]: convert_for_mongo(value)
                        for i, (column, value) in enumerate(row["values"].items())
                    }

                    # Elimina i file BLOB associati
                    for k, v in data.items():
                        if isinstance(v, str) and v.startswith("http://"):
                            delete_from_minio(v)

                    pk_field = next(iter(data))
                    mongo_db2[table].delete_one({pk_field: data[pk_field]})
                    logger.info(f"Delete from {table}: {data}")

                    # Elimina dalle collezioni nidificate
                   
                    if table == 'staff':
                        mongo_db2['staff_nested'].delete_one({pk_field: data[pk_field]})

                    elif table == 'payment':
                        update_nested_data('customers_nested', 'customer_id', data)
                        staff_id = data.get('staff_id')
                        if staff_id:
                            mongo_db2['staff_nested'].update_one(
                                {"staff_id": staff_id},
                                {"$pull": {"payments": {"payment_id": data["payment_id"]}}}
                            )
                            logger.info(f"Eliminato pagamento da staff_nested per staff_id {staff_id}: {data['payment_id']}")

                        
                    if table == 'customer':
                        mongo_db2['customers_nested'].delete_one({pk_field: data[pk_field]})

                    elif table == 'rental':
                        customer_id = data.get('customer_id')
                        if customer_id:
                            mongo_db2['customers_nested'].update_one(
                                {"customer_id": customer_id},
                                {"$pull": {"rentals": {"rental_id": data["rental_id"]}}}
                            )

                            logger.info(f"Rimosso rental da customers_nested (delete): {data['rental_id']}")

                    
                    if table == 'staff':
                        mongo_db2['staff_nested'].delete_one({pk_field: data[pk_field]})
                    elif table == 'payment':
                        # Aggiorna customers_nested
                        update_nested_data('customers_nested', 'customer_id', data)

                        # Aggiungi il pagamento in staff_nested (solo payment_id, amount, payment_date)
                        staff_id = data.get('staff_id')
                        if staff_id is not None:
                            nested_payment = {
                                "payment_id": data["payment_id"],
                                "amount": float(data["amount"]),
                                "payment_date": data["payment_date"].isoformat() if isinstance(data["payment_date"], (str,)) else data["payment_date"]
                            }

                            mongo_db2['staff_nested'].update_one(
                                {"staff_id": staff_id},
                                {"$pull": {"payments": {"payment_id": data["payment_id"]}}}
                            )


                            logger.info(f"Eliminato nuovo pagamento a staff_nested per staff_id {staff_id}: {nested_payment}")

                    
                    if table == 'film':
                        mongo_db2['film_nested'].delete_one({pk_field: data[pk_field]})
                    elif table == 'film_actor':
                        update_nested_data('film_nested', 'film_id', data)

                        film_id = data.get('film_id')
                        actor_id = data.get('actor_id')

                        if film_id is not None and actor_id is not None:
                            try:
                                nested_actor = {
                                    "actor_id": actor_id
                                }

                                result = mongo_db2['film_nested'].update_one(
                                    {"film_id": film_id},
                                    {"$pull": {"actors": {"actor_id": actor_id}}}
                                )

                                if result.modified_count > 0:
                                    logger.info(f"Attore rimosso da film_nested per film_id={film_id}: {nested_actor}")
                                else:
                                    logger.warning(f"Nessun attore da rimuovere trovato per actor_id={actor_id} in film_id={film_id}")

                            except Exception as e:
                                logger.error(f"Errore durante la rimozione dell'attore: {e}")
                        else:
                            logger.error(f"Dati mancanti per DELETE su film_actor: {data}")


                    elif table == 'film_category':
                        film_id = new.get('film_id')
                        category_id = new.get('category_id')

                        if film_id is not None and category_id is not None:
                            try:
                                # Ottieni il nome della categoria da tabella category
                                cursor.execute("SELECT name FROM category WHERE category_id = %s", (category_id,))
                                category_data = cursor.fetchone()

                                if not category_data:
                                    logger.warning(f"Categoria non trovata per category_id={category_id}")
                                    return

                                category_name = category_data["name"]

                                updated_category = {
                                    "category_id": category_id,
                                    "name": category_name
                                }

                                # Imposta l'intero array categories con un solo elemento
                                mongo_db2['film_nested'].update_one(
                                    {"film_id": film_id},
                                    {"$unset": {"categories": [updated_category]}}
                                )

                                logger.info(f"Campo categories sostituito con uno nuovo in film_nested per film_id={film_id}: {updated_category}")

                            except Exception as e:
                                logger.error(f"Errore durante aggiornamento film_category: {e}")
                        else:
                            logger.error(f"Dati mancanti per film_category: {new}")


            except Exception as e:
                logger.error(f"[CDC ERROR] Errore nell'elaborazione del record di {table}: {e}")

        # Salva posizione solo dopo TUTTI gli aggiornamenti
        redis_client.set('cdc_binlog_file', stream.log_file)
        redis_client.set('cdc_binlog_pos', stream.log_pos)

    stream.close()
    logger.info("=" * 50)
    logger.info("CDC completato.\n")


def update_address_references(address_id, new_address_data):
    # Aggiorna tutti i documenti che fanno riferimento a questo address_id
    update_ops = {
        "$set": {
            "address.address_id": new_address_data["address_id"],
            "address.address": new_address_data["address"],
            "address.address2": new_address_data["address2"],
            "address.city": new_address_data["city"],
            "address.country": new_address_data["country"],
            "address.postal_code": new_address_data["postal_code"]
        }
    }

    # Aggiorna nella collezione staff_nested
    mongo_db2['staff_nested'].update_many(
        {"address.address_id": address_id},
        update_ops
    )
    logger.info(f"Aggiornati {address_id} in staff_nested.")

    # Aggiorna nella collezione customers_nested
    mongo_db2['customers_nested'].update_many(
        {"address.address_id": address_id},
        update_ops
    )
    logger.info(f"Aggiornati {address_id} in customers_nested.")


def update_address_references(address_id, new_address_data):
    update_fields = {
        "address.address_id": new_address_data.get("address_id"),
        "address.address": new_address_data.get("address"),
        "address.address2": new_address_data.get("address2"),
        "address.district": new_address_data.get("district"),
        "address.postal_code": new_address_data.get("postal_code"),
        "address.city": new_address_data.get("city"),
        "address.country": new_address_data.get("country"),
        "address.phone": new_address_data.get("phone")
    }

    # Solo se 'phone' è presente lo aggiungiamo
    if "phone" in new_address_data:
        update_fields["address.phone"] = new_address_data["phone"]
    else:
        logger.warning(f"Campo 'phone' mancante in new_address_data con address_id={address_id}")

    update_ops = { "$set": update_fields }

    mongo_db2['staff_nested'].update_many(
        {"address.address_id": address_id},
        update_ops
    )
    logger.info(f"Aggiornati riferimenti address_id={address_id} in staff_nested.")

    mongo_db2['customers_nested'].update_many(
        {"address.address_id": address_id},
        update_ops
    )
    logger.info(f"Aggiornati riferimenti address_id={address_id} in customers_nested.")
