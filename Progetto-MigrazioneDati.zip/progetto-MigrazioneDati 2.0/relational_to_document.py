from mysql_conn import cursor
from mongo_conn import mongo_db2
from conversion import convert_for_mongo
from logger_config import setup_logger
from minio_utils import upload_to_minio
import base64
from datetime import datetime



logger = setup_logger()
def migrate_customers_with_rentals_and_payments():
    cursor.execute("SELECT * FROM customer")
    customers = cursor.fetchall()

    for customer in customers:
        customer_id = customer["customer_id"]
        existing = mongo_db2['customers_nested'].find_one({"customer_id": customer_id})

        # Ottieni solo rental_id e film_title
        cursor.execute("""
            SELECT r.rental_id, r.rental_date, r.return_date, f.title
            FROM rental r
            JOIN inventory i ON r.inventory_id = i.inventory_id
            JOIN film f ON i.film_id = f.film_id
            WHERE r.customer_id = %s
        """, (customer_id,))
        rentals = cursor.fetchall()

        formatted_rentals = [
            {
                "rental_id": rental["rental_id"],
                "rental_date": rental["rental_date"].isoformat() if rental["rental_date"] else None,
                "return_date": rental["return_date"].isoformat() if rental["return_date"] else None,
                "film": {
                    "title": rental["title"]
                }
            }
            for rental in rentals
        ]

        if existing:
            # Evita duplicati nei noleggi
            existing_rental_ids = {r["rental_id"] for r in existing.get("rentals", [])}
            new_rentals = [r for r in formatted_rentals if r["rental_id"] not in existing_rental_ids]

            if new_rentals:
                mongo_db2['customers_nested'].update_one(
                    {"customer_id": customer_id},
                    {"$push": {"rentals": {"$each": new_rentals}}}
                )
                mongo_db2['customers_nested'].update_one(
                    {"customer_id": customer_id},
                    {"$set": {
                        "first_name": customer["first_name"],
                        "last_name": customer["last_name"],
                        "email": customer["email"],
                        "last_update": customer["last_update"]
                       # "address": address
                    }}
                )

        else:
            new_customer_doc = {
                "customer_id": customer_id,
                "first_name": customer["first_name"],
                "last_name": customer["last_name"],
                "email": customer["email"],
                "last_update": customer["last_update"],
              #  "address": address,
                "rentals": formatted_rentals
            }

            mongo_db2['customers_nested'].insert_one(new_customer_doc)

    logger.info("Migrazione customer completata.")


def migrate_film_with_actors_and_categories():
    cursor.execute("SELECT * FROM film")
    films = cursor.fetchall()

    for film in films:
        film_id = film['film_id']
        language_id = film['language_id']

        # Recupera il documento esistente da MongoDB
        existing = mongo_db2['film_nested'].find_one({"film_id": film_id})

        # Lingua
        cursor.execute("SELECT name FROM language WHERE language_id = %s", (language_id,))
        language = cursor.fetchone()
        language_name = language['name'] if language else None

        # Attori
        cursor.execute("""
            SELECT a.actor_id, a.first_name, a.last_name
            FROM actor a
            JOIN film_actor fa ON a.actor_id = fa.actor_id
            WHERE fa.film_id = %s
        """, (film_id,))
        actors = cursor.fetchall()
        actor_list = [
            {'actor_id': a['actor_id'], 'name': f"{a['first_name']} {a['last_name']}"}
            for a in actors
        ]

        # Categorie
        cursor.execute("""
            SELECT c.category_id, c.name
            FROM category c
            JOIN film_category fc ON c.category_id = fc.category_id
            WHERE fc.film_id = %s
        """, (film_id,))
        categories = cursor.fetchall()
        #category_list = [{'category_id': c['category_id'], 'name': c['name']} for c in categories]
        category_list = [{'category_id': c['category_id']} for c in categories]
        
        # Conversione film base
        film_doc = convert_for_mongo(film)
        film_doc.pop('special_features', None)


        # Pulizia chiavi non rilevanti
        film_doc.pop('language_id', None)
        film_doc.pop('original_language_id', None)

        # Aggiunta lingua, attori e categorie
        #film_doc['language'] = language_name
        film_doc['actors'] = actor_list
        film_doc['categories'] = category_list

        # Operazioni di aggiornamento specifico
        update_ops = {}

        # Gestire l'inserimento o l'aggiornamento
        if existing:
            # Controlla se il documento esistente è obsoleto (basato su `last_update`)
            if film['last_update'] > existing.get('last_update', film['last_update']):
                # Aggiornamenti parziali, simili a quanto fatto nel mio esempio precedente
                #if existing.get('language') != language_name:
                    #update_ops["$set"] = {"language": language_name}
                if existing.get('actors') != actor_list:
                    update_ops["$set"]["actors"] = actor_list
                if existing.get('categories') != category_list:
                    update_ops["$set"]["categories"] = category_list
                if film['last_update'] > existing.get('last_update', film['last_update']):
                    update_ops.setdefault("$set", {})["last_update"] = film['last_update']

                # Esegui l'operazione di aggiornamento parziale
                if update_ops:
                    mongo_db2['film_nested'].update_one(
                        {"film_id": film_id},
                        update_ops
                    )

                logger.info(f"Aggiornato film_id {film_id} con attori, categorie e lingua.")
        else:
            # Primo inserimento di film (se non esiste)
            mongo_db2['film_nested'].insert_one(film_doc)
            logger.info(f"Inserito nuovo film_id {film_id} con attori, categorie e lingua.")


def migrate_staff_with_address_and_payments():
    logger.info("Inizio migrazione staff  -> address + payments...")

    cursor.execute("SELECT * FROM staff")
    staff_members = cursor.fetchall()

    for staff in staff_members:
        staff_id = staff['staff_id']
        existing = mongo_db2['staff_nested'].find_one({"staff_id": staff_id})

        # Pagamenti
        cursor.execute("""
            SELECT payment_id, amount, payment_date
            FROM payment WHERE staff_id = %s
        """, (staff_id,))
        payments = cursor.fetchall()

        new_payments = [
            {
                "payment_id": payment['payment_id'],
                "amount": float(payment['amount']),
                "payment_date": payment['payment_date'].isoformat()
            }
            for payment in payments
        ]

        # Recupero indirizzo
        address = None
        if staff.get('address_id'):
            cursor.execute("""
                SELECT a.address_id, a.address, a.address2, a.district, a.postal_code, a.phone
                FROM address a
                WHERE a.address_id = %s
            """, (staff['address_id'],))
            addr = cursor.fetchone()
            if addr:
                address = {
                    "address_id": addr["address_id"],
                    "address": addr["address"],
                    "address2": addr["address2"] if addr["address2"] else None,
                    "district": addr["district"],
                    "postal_code": addr["postal_code"],
                    "phone": addr["phone"]
                }

        if existing:
            existing_payment_ids = {p['payment_id'] for p in existing.get('payments', [])}
            filtered_new = [p for p in new_payments if p['payment_id'] not in existing_payment_ids]

            update_ops = {}

            if filtered_new:
                logger.info(f"Aggiungendo {len(filtered_new)} nuovi pagamenti per staff_id {staff_id}")
                update_ops["$addToSet"] = {"payments": {"$each": filtered_new}}

            if staff['last_update'] > existing.get('last_update', staff['last_update']):
                update_ops.setdefault("$set", {})["last_update"] = staff['last_update']
                if staff.get('picture') and len(staff['picture']) > 0:
                    update_ops["$set"]["picture"] = upload_to_minio(staff['picture'])

                if address:
                    update_ops["$set"]["address"] = address

            if update_ops:
                mongo_db2['staff_nested'].update_one(
                    {"staff_id": staff_id},
                    update_ops
                )

        else:
            picture_url = None
            if staff.get('picture') and len(staff['picture']) > 0:
                picture_url = upload_to_minio(staff['picture'])

            staff_doc = {
                "staff_id": staff_id,
                "first_name": staff['first_name'],
                "last_name": staff['last_name'],
                "email": staff['email'],
                "username": staff['username'],
                "password": staff['password'],
                "active": staff['active'],
                "last_update": staff['last_update'],
                "picture": picture_url,
                "address": address,
                "payments": new_payments
            }

            mongo_db2['staff_nested'].insert_one(staff_doc)

    logger.info("Migrazione staff completata.")

def run_all_nested_migrations():
    logger.info("Inizio migrazione nidificata di tabelle relazionali...")

    # Migrazione clienti con conferma per andare avanti
    migrate_customers_with_rentals_and_payments()
    confirmation = input("Migrazione clienti completata. Premi 'y' per proseguire con la migrazione dei film: ")
    if confirmation.lower() != 'y':
        logger.info("Migrazione interrotta.")
        return

    # Migrazione film con conferma per andare avanti
    migrate_film_with_actors_and_categories()
    confirmation = input("Migrazione film completata. Premi 'y' per proseguire con la migrazione dello staff: ")
    if confirmation.lower() != 'y':
        logger.info("Migrazione interrotta.")
        return

    # Migrazione staff con conferma per andare avanti
    migrate_staff_with_address_and_payments()
    confirmation = input("Migrazione staff completata. Premi 'y' per terminare: ")
    if confirmation.lower() != 'y':
        logger.info("Migrazione interrotta.")
        return

    logger.info("Migrazione nidificata completata.")
   
#quando si aggiunge un nuovo staff, si deve controllare se esiste già in MongoDB
def build_nested_staff_document(staff):
    staff_id = staff['staff_id']
    address_id = staff.get('address_id')

    # Recupera address associato allo staff
    address = None
    if address_id:
        cursor.execute("""
            SELECT a.address_id, a.address, a.address2, a.district, a.postal_code, a.phone
            FROM address a
            WHERE a.address_id = %s
        """, (address_id,))
        addr = cursor.fetchone()
        if addr:
            address = {
                "address_id": addr["address_id"],
                "address": addr["address"],
                "address2": addr["address2"] if addr["address2"] else None,
                "district": addr["district"],
                "postal_code": addr["postal_code"],
                "phone": addr["phone"]
            }

    # Recupera pagamenti associati allo staff
    cursor.execute("""
        SELECT payment_id, amount, payment_date
        FROM payment
        WHERE staff_id = %s
    """, (staff_id,))
    payments = cursor.fetchall()

    # Gestione immagine
    picture_url = None
    picture = staff.get("picture")

    if picture:
        try:
            if isinstance(picture, str):
                picture_bytes = base64.b64decode(picture)
                picture_url = upload_to_minio(picture_bytes)
            elif isinstance(picture, (bytes, bytearray)):
                picture_url = upload_to_minio(picture)
        except Exception as e:
            print("[ERROR] Errore nella gestione dell'immagine:", e)

    # Costruzione documento staff completo
    staff_doc = {
        "staff_id": staff_id,
        "first_name": staff.get("first_name"),
        "last_name": staff.get("last_name"),
        "email": staff.get("email"),
        "username": staff.get("username"),
        "password": staff.get("password"),
        "active": staff.get("active"),
        "last_update": staff.get("last_update"),
        "picture": picture_url,
        "address": address,
        "payments": [
            {
                "payment_id": p["payment_id"],
                "amount": float(p["amount"]),
                "payment_date": p["payment_date"].isoformat()
            } for p in payments
        ]
    }

    return staff_doc


def build_nested_film_document(film):
    film_id = film['film_id']
    language_id = film.get('language_id')

    # Recupera la lingua
    cursor.execute("SELECT name FROM language WHERE language_id = %s", (language_id,))
    language = cursor.fetchone()
    language_name = language['name'] if language else None

    # Recupera attori del film
    cursor.execute("""
        SELECT a.actor_id, a.first_name, a.last_name
        FROM actor a
        JOIN film_actor fa ON a.actor_id = fa.actor_id
        WHERE fa.film_id = %s
    """, (film_id,))
    actors = cursor.fetchall()
    actor_list = [
        {
            "actor_id": actor["actor_id"],
            "name": f"{actor['first_name']} {actor['last_name']}"
        }
        for actor in actors
    ]

    # Recupera categorie del film
    cursor.execute("""
        SELECT c.category_id, c.name
        FROM category c
        JOIN film_category fc ON c.category_id = fc.category_id
        WHERE fc.film_id = %s
    """, (film_id,))
    categories = cursor.fetchall()
    category_list = [
        {
            "category_id": cat["category_id"],
            #"name": cat["name"]
        }
        for cat in categories
    ]

    # Conversione dati del film in formato MongoDB
    film_doc = convert_for_mongo(film) 
    film_doc.pop('special_features', None)
 # Presupponiamo che converta tipi SQL → compatibili MongoDB
    # Converti tutti i set in list (MongoDB non supporta i set)
    for key, value in film_doc.items():
        if isinstance(value, set):
            film_doc[key] = list(value)


    # Rimozione di chiavi SQL non necessarie
    film_doc.pop("language_id", None)
    film_doc.pop("original_language_id", None)
    film_doc.pop('special_features', None)


    # Aggiunta dei dati annidati
    #film_doc["language"] = language_name
    film_doc["actors"] = actor_list
    film_doc["categories"] = category_list  # Ora 'category' è un array con oggetti {category_id, name}

    return film_doc



def build_nested_customer_document(customer):
    customer_id = customer['customer_id']
    # Recupera noleggi (solo rental_id e titolo del film)
    cursor.execute("""
        SELECT r.rental_id, r.rental_date, r.return_date, f.title
        FROM rental r
        JOIN inventory i ON r.inventory_id = i.inventory_id
        JOIN film f ON i.film_id = f.film_id
        WHERE r.customer_id = %s
    """, (customer_id,))
    rentals = cursor.fetchall()

    # Costruzione documento customer completo
    customer_doc = {
        "customer_id": customer_id,
        "first_name": customer.get("first_name"),
        "last_name": customer.get("last_name"),
        "email": customer.get("email"),
        "last_update": customer.get("last_update"),
        "rentals": [
            {
                "rental_id": rental["rental_id"],
                "rental_date": rental["rental_date"].isoformat() if rental.get("rental_date") else None,
                "return_date": rental["return_date"].isoformat() if rental.get("return_date") else None,
                "film": {
                    "title": rental["title"]
                }
            } for rental in rentals
        ]
    }

    return customer_doc


def build_nested_customer_document_from_db(customer_id):
    # Recupera il customer
    cursor.execute("""
        SELECT * FROM customer WHERE customer_id = %s
    """, (customer_id,))
    customer = cursor.fetchone()

    if not customer:
        return None  # Se il cliente non esiste, non fare nulla

    address_id = customer.get('address_id')

    # Recupera noleggi (rentals) associati al customer
    cursor.execute("""
        SELECT r.rental_id, r.rental_date, r.return_date,
               i.inventory_id, f.title
        FROM rental r
        JOIN inventory i ON r.inventory_id = i.inventory_id
        JOIN film f ON i.film_id = f.film_id
        WHERE r.customer_id = %s
    """, (customer_id,))
    rentals = cursor.fetchall()

    # Costruzione documento customer completo
    customer_doc = {
        "customer_id": customer_id,
        "first_name": customer.get("first_name"),
        "last_name": customer.get("last_name"),
        "email": customer.get("email"),
        "last_update": customer.get("last_update"),
        "rentals": [
            {
                "rental_id": rental["rental_id"],
                "rental_date": rental["rental_date"].isoformat() if rental["rental_date"] else None,
                "return_date": rental["return_date"].isoformat() if rental["return_date"] else None,
                "film_title": rental["title"]
            } for rental in rentals
        ]
    }

    return customer_doc