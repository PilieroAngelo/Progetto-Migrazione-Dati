import pymysql
from config import mysql_settings, mysql_db_name

mysql_conn = pymysql.connect(
    host=mysql_settings["host"],
    user=mysql_settings["user"],
    password=mysql_settings["passwd"],
    database=mysql_db_name,
    cursorclass=pymysql.cursors.DictCursor
)
cursor = mysql_conn.cursor()

def get_column_names(table_name):
    cursor.execute(f"DESCRIBE {table_name}")
    return [row['Field'] for row in cursor.fetchall()]
