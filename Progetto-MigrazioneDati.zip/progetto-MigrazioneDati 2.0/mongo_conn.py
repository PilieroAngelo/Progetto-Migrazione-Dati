from pymongo import MongoClient
from config import MONGO_URI

mongo_client = MongoClient(MONGO_URI)
mongo_db = mongo_client["sakila_mongo"]
mongo_db2 = mongo_client["sakila_nested"]