from mysql_conn import cursor, get_column_names
from mongo_conn import mongo_db
from conversion import convert_for_mongo
from logger_config import setup_logger

logger = setup_logger()

# Mappatura BU -> Tabelle
BU_TABLES = {
    "customer_management": ["customer", "address", "city", "country"],
    "film_inventory": ["film", "category", "inventory", "film_category", "language"],
    "rental_management": ["rental", "payment", "staff", "store"],
     "film_info":["actor", "film_actor", "film_text"]
}

def fetch_table_data(table):
    cursor.execute(f"SELECT * FROM {table}")
    return cursor.fetchall()

def migrate_table(table):
    logger.info(f"Inizio migrazione tabella '{table}'")
    rows = fetch_table_data(table)
    column_names = get_column_names(table)

    mongo_db[table].delete_many({})

    if rows:
        cleaned_rows = [{column: convert_for_mongo(value) for column, value in row.items()} for row in rows]
        mongo_db[table].insert_many(cleaned_rows)
        logger.info(f" {len(rows)} record migrati nella collection '{table}'")
    else:
        logger.warning(f"  Nessun dato trovato nella tabella '{table}'")

def migrate_bu(bu_name):
    tables = BU_TABLES.get(bu_name)
    if not tables:
        logger.error(f" BU '{bu_name}' non trovata.")
        return

    logger.info(f"\n Inizio migrazione BU: {bu_name}")
    for table in tables:
        migrate_table(table)
    logger.info(f" Migrazione BU '{bu_name}' completata.\n")

def initial_migration():
    migrated = set()

    for bu in BU_TABLES:
        print(f"\n--- Inizio migrazione BU '{bu}' ---")
        tables = BU_TABLES[bu]
        summary = {}

        for table in tables:
            logger.info(f"Inizio migrazione tabella '{table}'")
            rows = fetch_table_data(table)
            column_names = get_column_names(table)

            mongo_db[table].delete_many({})

            if rows:
                cleaned_rows = [{column: convert_for_mongo(value) for column, value in row.items()} for row in rows]
                mongo_db[table].insert_many(cleaned_rows)
                count = len(rows)
                logger.info(f" {count} record migrati nella collection '{table}'")
                summary[table] = count
            else:
                logger.warning(f"  Nessun dato trovato nella tabella '{table}'")
                summary[table] = 0

        migrated.add(bu)
    print("\n Migrazione iniziale completata.")