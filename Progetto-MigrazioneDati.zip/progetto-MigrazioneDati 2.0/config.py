mysql_settings = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "passwd": "root"
}
mysql_db_name = "sakila"

MINIO = {
    'endpoint': 'localhost:9000',
    'access_key': '[nome utente]',
    'secret_key': '[password]',
    'bucket': '[nome bucket]'
}

MONGO_URI = "mongodb://localhost:27017/"
REDIS_HOST = 'localhost'
REDIS_PORT = 6379
