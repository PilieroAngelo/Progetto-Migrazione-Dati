import threading
from minio_utils import create_minio_bucket
from initial_migration import initial_migration
from cdc import start_cdc
from redis_cache import get_staff_row_count, get_film_category_counts
from redis_conn import redis_client
from logger_config import setup_logger
from mysql_replication import start_replication
from relational_to_document import run_all_nested_migrations

logger = setup_logger()

def start_cdc_thread():
    logger.info("Avvio della sincronizzazione in tempo reale...")
    start_cdc()

def start_migration_thread():
    logger.info("Avvio della migrazione annidata...")
    run_all_nested_migrations()

def start_replication_thread():
    logger.info("Avvio della replicazione binlog...")
    start_replication()

def main():
    create_minio_bucket()

    if not redis_client.get("initial_migration_done"):
        logger.info("Prima esecuzione rilevata: avvio migrazione iniziale.")
        initial_migration()
        redis_client.set("initial_migration_done", "true")
    else:
        logger.info("Migrazione iniziale già eseguita: salto.")

    logger.info(f"Numero di righe nella tabella 'staff': {get_staff_row_count()}")
    logger.info(f"Numero di film per categoria: {get_film_category_counts()}")

    logger.info("Avvio dei processi in parallelo.")

    # Avvio dei thread per CDC, migrazione e replicazione
    cdc_thread = threading.Thread(target=start_cdc_thread)
    migration_thread = threading.Thread(target=start_migration_thread)
    replication_thread = threading.Thread(target=start_replication_thread)

    cdc_thread.start()
    migration_thread.start()
    replication_thread.start()

    cdc_thread.join()
    migration_thread.join()
    replication_thread.join()

    logger.info("Tutti i processi sono stati completati.")

if __name__ == "__main__":
    main()