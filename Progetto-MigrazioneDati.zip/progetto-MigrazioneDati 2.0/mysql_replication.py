from pymysqlreplication import BinLogStreamReader
from pymysqlreplication.row_event import WriteRowsEvent, UpdateRowsEvent, DeleteRowsEvent
import mysql.connector
import datetime
from redis_conn import redis_client
from logger_config import setup_logger
from config import mysql_settings  # Assicurati che contenga host, port, user, passwd, charset

logger = setup_logger()

def normalize_datetime(value):
    if isinstance(value, datetime.datetime):
        return value.replace(microsecond=0).strftime('%Y-%m-%d %H:%M:%S')
    return value

def normalize_row(row_dict):
    normalized = {}
    for k, v in row_dict.items():
        if v is None:
            normalized[k] = None
        else:
            normalized[k] = normalize_datetime(v)
    return normalized

def start_replication():
    logger.info("="*50)
    logger.info("Avvio della replicazione binlog...")
    logger.info("="*50)

    log_file = redis_client.get('replication_binlog_file')
    log_pos = redis_client.get('replication_binlog_pos')

    # Decodifica i valori di log_file e log_pos se sono in formato byte
    if isinstance(log_file, bytes):
        log_file = log_file.decode()
    if isinstance(log_pos, bytes):
        log_pos = log_pos.decode()

    # Se esiste una posizione del binlog precedente, controlla se è cambiata
    if log_file and log_pos:
        logger.info(f"Riprendendo replicazione da {log_file}:{log_pos}")
    else:
        logger.info("Avvio replicazione dalla posizione corrente del binlog.")

    # Connessione al database per la replica
    replica_conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="sakila2"
    )
    replica_cursor = replica_conn.cursor()

    # Configurazione del reader per il binlog
    stream = BinLogStreamReader(
        connection_settings=mysql_settings,
        server_id=100,
        blocking=True,
        only_events=[WriteRowsEvent, UpdateRowsEvent, DeleteRowsEvent],
        only_schemas=["sakila"],
        resume_stream=True,
        log_file=log_file if log_file else None,
        log_pos=int(log_pos) if log_pos else None
    )

    # Processa gli eventi del binlog
    for binlogevent in stream:
        table = binlogevent.table

        for row in binlogevent.rows:
            try:
                # Applicazione dell'evento Write (INSERT)
                if isinstance(binlogevent, WriteRowsEvent):
                    values = normalize_row(row["values"])
                    columns = ", ".join(values.keys())
                    placeholders = ", ".join(["%s"] * len(values))
                    sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
                    replica_cursor.execute(sql, list(values.values()))
                    logger.info(f"INSERT in {table}: {values}")

                # Applicazione dell'evento Update
                elif isinstance(binlogevent, UpdateRowsEvent):
                    after = normalize_row(row["after_values"])
                    before = normalize_row(row["before_values"])

                    # Usa il primo campo (chiave primaria) come condizione per la WHERE
                    pk_field = next(iter(before))  
                    set_clause = ", ".join([f"{col} = %s" for col in after.keys()])
                    where_clause = f"{pk_field} = %s"
                    sql = f"UPDATE {table} SET {set_clause} WHERE {where_clause}"

                    try:
                        replica_cursor.execute(sql, list(after.values()) + [before[pk_field]])
                        logger.info(f"UPDATE in {table}: {after}")
                    except Exception as e:
                        logger.error(f"Errore durante UPDATE in {table}: {e}")


                # Applicazione dell'evento Delete
                elif isinstance(binlogevent, DeleteRowsEvent):
                    values = normalize_row(row["values"])
                    where_clause = " AND ".join([f"{col} IS NULL" if val is None else f"{col} = %s"
                                                 for col, val in values.items()])
                    sql = f"DELETE FROM {table} WHERE {where_clause}"
                    params = [val for val in values.values() if val is not None]
                    replica_cursor.execute(sql, params)
                    logger.info(f"DELETE from {table}: {values}")

                # Commit delle modifiche nel database
                replica_conn.commit()

            except mysql.connector.Error as err:
                logger.error(f"Errore SQL su tabella {table}: {err}")

        # Dopo aver applicato l'evento, aggiorna la posizione nel binlog
        redis_client.set("replication_binlog_file", stream.log_file)
        redis_client.set("replication_binlog_pos", stream.log_pos)

    # Chiusura delle connessioni
    stream.close()
    replica_cursor.close()
    replica_conn.close()

    logger.info(" Replicazione terminata correttamente.")