from decimal import Decimal
from datetime import datetime
from minio_utils import upload_to_minio

def convert_for_mongo(obj):
    if isinstance(obj, list):
        return [convert_for_mongo(item) for item in obj]
    elif isinstance(obj, dict):
        return {str(k): convert_for_mongo(v) for k, v in obj.items()}
    elif isinstance(obj, bytes):
        try:
            return obj.decode('utf-8')
        except UnicodeDecodeError:
            return upload_to_minio(obj)
    elif isinstance(obj, Decimal):
        return float(obj)
    elif isinstance(obj, datetime):
        return obj
    return obj