import boto3
from botocore.client import Config
from botocore.exceptions import ClientError
import hashlib
import filetype
from config import MINIO
from logger_config import setup_logger

logger = setup_logger()

minio_client = boto3.client(
    's3',
    endpoint_url=f"http://{MINIO['endpoint']}",
    aws_access_key_id=MINIO['access_key'],
    aws_secret_access_key=MINIO['secret_key'],
    config=Config(signature_version='s3v4', s3={'addressing_style': 'path'}),
    region_name='us-east-1'
)

def create_minio_bucket():
    try:
        minio_client.head_bucket(Bucket=MINIO['bucket'])
        logger.info(f"[MinIO] Bucket '{MINIO['bucket']}' già esistente.")
    except Exception as e:
        logger.info(f"[MinIO] Bucket non trovato. Creazione in corso... ({e})")
        minio_client.create_bucket(Bucket=MINIO['bucket'])

def upload_to_minio(data):
    try:
        kind = filetype.guess(data)
        extension = kind.extension if kind else 'bin'
        mime_type = kind.mime if kind else 'application/octet-stream'

        file_hash = hashlib.sha256(data).hexdigest()
        filename = f"{file_hash}.{extension}"

        try:
            minio_client.head_object(Bucket=MINIO['bucket'], Key=filename)
        except ClientError as e:
            if e.response['Error']['Code'] == '404':
                minio_client.put_object(Bucket=MINIO['bucket'], Key=filename, Body=data)
            else:
                raise e

        return f"http://{MINIO['endpoint']}/{MINIO['bucket']}/{filename}"

    except Exception as e:
        logger.error(f"[MinIO] Errore upload: {e}")
        return None

def delete_from_minio(file_url):
    try:
        key = file_url.split(f"/{MINIO['bucket']}/")[-1]
        minio_client.delete_object(Bucket=MINIO['bucket'], Key=key)
        logger.info(f"[MinIO] File eliminato: {key}")
    except Exception as e:
        logger.error(f"[MinIO] Errore durante l'eliminazione del file: {e}")
